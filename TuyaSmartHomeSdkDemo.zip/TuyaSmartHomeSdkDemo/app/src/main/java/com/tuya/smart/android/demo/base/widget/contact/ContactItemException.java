package com.tuya.smart.android.demo.base.widget.contact;

public class ContactItemException extends Exception {

    public ContactItemException() {
    }

    public ContactItemException(String msg) {
        super(msg);
    }


}
