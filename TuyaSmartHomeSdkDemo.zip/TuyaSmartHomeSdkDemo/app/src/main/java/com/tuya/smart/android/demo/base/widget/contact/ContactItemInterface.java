package com.tuya.smart.android.demo.base.widget.contact;

public interface ContactItemInterface {

    String getItemForIndex();

    String getNumber();

    String getKey();
}
