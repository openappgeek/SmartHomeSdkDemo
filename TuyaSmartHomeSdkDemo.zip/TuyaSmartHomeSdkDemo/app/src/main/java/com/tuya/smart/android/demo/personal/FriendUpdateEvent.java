package com.tuya.smart.android.demo.personal;


/**
 * Created by letian on 15/6/2.
 */
public interface FriendUpdateEvent {
    void onEvent(FriendEventModel event);
}
