package com.tuya.smart.android.demo.personal;

/**
 * Created by leaf on 15/12/21.
 * 共享
 */
public interface ISharedMemberAddView {
    String getMobile();

    void setMobile(String mobile);

//    String getNickname();

//    void setNickName(String nickName);

    void setCountry(String name, String code);
}
