package com.tuya.smart.android.demo.base.view;

/**
 * Created by letian on 16/7/18.
 */
public interface IHomeView {
    void onItem(int pos);

    void offItem(int pos);

    void goToFamilyEmptyActivity();

}
