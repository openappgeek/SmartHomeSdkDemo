package com.tuya.smart.android.demo.personal;


import java.util.ArrayList;

/**
 * Created by leaf on 15/12/21.
 * 添加共享
 */
public interface ISharedMemberAddModel {
    ArrayList<String> getRelationNameList();

    ArrayList<String> getRelationList();
}
